
// WebCidadão Backend Integrado
// Servidor Express + SQLite com autenticação JWT, demandas, agendamentos,
// notificações e histórico, pronto para conversar com o front existente.
//
// Para rodar:
//   cd backend
//   npm install
//   cp .env.example .env   (opcional, ou use valores padrão)
//   node server.js
//
// Depois abra http://localhost:3333/login.html

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

// =============================
// Configuração básica
// =============================
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Caminhos importantes
const ROOT_DIR = path.join(__dirname, '..');
const FRONTEND_DIR = path.join(ROOT_DIR, 'Frontend');
const DATA_DIR = path.join(__dirname, 'data');
const UPLOADS_DIR = path.join(__dirname, 'uploads');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

// Banco de dados SQLite
const DB_PATH = path.join(DATA_DIR, 'webcidadao.db');
const db = new sqlite3.Database(DB_PATH);

// Segredo JWT
const JWT_SECRET = process.env.JWT_SECRET || 'webcidadao-dev-secret';

// Multer para upload de imagens (demanda)
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOADS_DIR);
  },
  filename: function (req, file, cb) {
    // nome simples: timestamp-original
    const sanitized = file.originalname.replace(/[^a-z0-9_.-]/gi, '_').toLowerCase();
    cb(null, Date.now() + '-' + sanitized);
  }
});
const upload = multer({ storage });

// =============================
// Helpers
// =============================
function run(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}
function all(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, function (err, rows) {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}
function get(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, function (err, row) {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function nowISO() {
  return new Date().toISOString();
}

// cria notificação para 1 usuário
async function pushNotificacao(user_id, mensagem) {
  await run(db,
    `INSERT INTO notificacoes (user_id, mensagem, lida, timestamp)
     VALUES (?,?,0,?)`,
    [user_id, mensagem, nowISO()]
  );
}

// cria histórico (log de evento)
async function pushHistorico(user_id, tipo, mensagem, ref_tipo, ref_id) {
  await run(db,
    `INSERT INTO historico (user_id, tipo, mensagem, ref_tipo, ref_id, timestamp)
     VALUES (?,?,?,?,?,?)`,
    [user_id, tipo, mensagem, ref_tipo, ref_id, nowISO()]
  );
}

// cria notificação para TODOS admins
async function notifyAllAdmins(mensagem) {
  const admins = await all(db, `SELECT id FROM users WHERE role='admin'`);
  for (const a of admins) {
    await pushNotificacao(a.id, mensagem);
  }
}

// =============================
// Inicialização do banco
// =============================
async function initDb() {
  // Tabela de usuários
  await run(db, `
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      email TEXT UNIQUE,
      password_hash TEXT,
      role TEXT CHECK(role IN ('admin','cidadao')) NOT NULL,
      created_at TEXT
    )
  `);

  // Demandas
  await run(db, `
    CREATE TABLE IF NOT EXISTS demandas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      title TEXT,
      category TEXT,
      description TEXT,
      status TEXT,
      priority TEXT,
      created_at TEXT
    )
  `);

  // Imagens ligadas à demanda
  await run(db, `
    CREATE TABLE IF NOT EXISTS images (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      demanda_id INTEGER,
      file_path TEXT
    )
  `);

  // Agendamentos
  await run(db, `
    CREATE TABLE IF NOT EXISTS agendamentos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      servico TEXT,
      data TEXT,
      hora TEXT,
      obs TEXT,
      status TEXT,
      created_at TEXT
    )
  `);

  // Notificações
  await run(db, `
    CREATE TABLE IF NOT EXISTS notificacoes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      mensagem TEXT,
      lida INTEGER DEFAULT 0,
      timestamp TEXT
    )
  `);

  // Histórico
  await run(db, `
    CREATE TABLE IF NOT EXISTS historico (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      tipo TEXT,
      mensagem TEXT,
      ref_tipo TEXT,
      ref_id INTEGER,
      timestamp TEXT
    )
  `);

  // Usuários demo / padrão
  async function ensureUser(name, email, password, role) {
    const exists = await get(db, `SELECT id FROM users WHERE email=?`, [email]);
    if (!exists) {
      const hash = await bcrypt.hash(password, 10);
      await run(
        db,
        `INSERT INTO users (name,email,password_hash,role,created_at)
         VALUES (?,?,?,?,?)`,
        [name, email, hash, role, nowISO()]
      );
    }
  }

  await ensureUser('Administrador Demo', 'admin@demo.com', '12345', 'admin');
  await ensureUser('Cidadão Demo', 'cidadao@demo.com', '12345', 'cidadao');

  // segundo admin padrão opcional
  await ensureUser('Administrador', 'admin@webcidadao.local', 'admin123', 'admin');
}

// =============================
// Middleware de autenticação
// =============================
async function authRequired(req, res, next) {
  const hdr = req.headers['authorization'] || '';
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: 'missing token' });
  }
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    // carrega usuário
    const u = await get(db, `SELECT id,name,email,role FROM users WHERE id=?`, [payload.id]);
    if (!u) return res.status(401).json({ error: 'invalid user' });
    req.user = u;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'invalid token' });
  }
}

function requireRole(role) {
  return function(req,res,next){
    if (!req.user) return res.status(401).json({ error:'unauthenticated' });
    if (req.user.role !== role) return res.status(403).json({ error:'forbidden' });
    next();
  };
}

// =============================
// Rotas de autenticação
// =============================

// Registro (cidadão ou admin - mas normalmente cidadão)
app.post('/api/auth/register', async (req,res)=>{
  try {
    const { name, email, password, role } = req.body || {};

    if(!name || !email || !password){
      return res.status(400).json({ error:'missing fields' });
    }

    const finalRole = role === 'admin' ? 'admin' : 'cidadao';

    const exists = await get(db, `SELECT id FROM users WHERE email=?`, [email]);
    if (exists) {
      return res.status(400).json({ error:'email already registered' });
    }

    const hash = await bcrypt.hash(password, 10);
    const result = await run(
      db,
      `INSERT INTO users (name,email,password_hash,role,created_at)
       VALUES (?,?,?,?,?)`,
      [name, email, hash, finalRole, nowISO()]
    );

    const newId = result.lastID;
    const user = { id:newId, name, email, role: finalRole };
    const token = jwt.sign({ id:newId, role:finalRole }, JWT_SECRET, { expiresIn:'7d' });

    res.json({ token, user });
  } catch (err) {
    console.error('register error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// Login
app.post('/api/auth/login', async (req,res)=>{
  try{
    const { email, password } = req.body || {};
    if(!email || !password){
      return res.status(400).json({ error:'missing email/password' });
    }
    const u = await get(db, `SELECT id,name,email,password_hash,role FROM users WHERE email=?`, [email]);
    if(!u){
      return res.status(401).json({ error:'invalid credentials' });
    }
    const ok = await bcrypt.compare(password, u.password_hash);
    if(!ok){
      return res.status(401).json({ error:'invalid credentials' });
    }
    const user = { id:u.id, name:u.name, email:u.email, role:u.role };
    const token = jwt.sign({ id:u.id, role:u.role }, JWT_SECRET, { expiresIn:'7d' });

    res.json({ token, user });
  }catch(err){
    console.error('login error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// perfil atual
app.get('/api/auth/me', authRequired, async (req,res)=>{
  res.json({ user:req.user });
});

// =============================
// Demandas
// =============================

// Listar demandas
app.get('/api/demandas', authRequired, async (req,res)=>{
  try {
    if (req.user.role === 'admin') {
      // admin vê todas + info do usuário
      const demandas = await all(db, `
        SELECT d.id, d.title, d.category, d.description, d.status, d.priority,
               d.created_at,
               u.name AS user_name, u.email AS user_email
        FROM demandas d
        LEFT JOIN users u ON u.id = d.user_id
        ORDER BY d.created_at DESC
      `);

      // carrega imagens por demanda
      for (const d of demandas) {
        const imgs = await all(db, `SELECT file_path FROM images WHERE demanda_id=?`, [d.id]);
        d.images = imgs.map(i => '/uploads/' + path.basename(i.file_path));
      }

      return res.json(demandas);
    } else {
      // cidadão só vê as dele
      const demandas = await all(db, `
        SELECT d.id, d.title, d.category, d.description, d.status, d.priority,
               d.created_at
        FROM demandas d
        WHERE d.user_id=?
        ORDER BY d.created_at DESC
      `, [req.user.id]);

      for (const d of demandas) {
        const imgs = await all(db, `SELECT file_path FROM images WHERE demanda_id=?`, [d.id]);
        d.images = imgs.map(i => '/uploads/' + path.basename(i.file_path));
      }

      return res.json(demandas);
    }
  } catch(err){
    console.error('get demandas error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// Criar nova demanda (cidadão)
app.post('/api/demandas', authRequired, requireRole('cidadao'), upload.array('imagem',4), async (req,res)=>{
  try{
    const { titulo, categoria, descricao, prioridade } = req.body || {};
    const status = 'aberta';
    const created_at = nowISO();

    const result = await run(
      db,
      `INSERT INTO demandas (user_id,title,category,description,status,priority,created_at)
       VALUES (?,?,?,?,?,?,?)`,
      [req.user.id, titulo || '', categoria || '', descricao || '', status, prioridade || null, created_at]
    );
    const demandaId = result.lastID;

    // salvar imagens (se houver)
    if (req.files && req.files.length){
      for (const f of req.files) {
        await run(db,
          `INSERT INTO images (demanda_id,file_path) VALUES (?,?)`,
          [demandaId, f.path]
        );
      }
    }

    // histórico + notificação pro cidadão
    await pushHistorico(req.user.id,
      'demanda',
      `Demanda #${demandaId} criada com status '${status}'`,
      'demanda',
      demandaId
    );

    // notifica admins
    await notifyAllAdmins(`Nova demanda #${demandaId} aberta por ${req.user.name}`);

    res.json({ ok:true, demanda_id: demandaId });
  }catch(err){
    console.error('post demanda error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// Atualizar status da demanda (admin)
app.post('/api/demandas/:id/status', authRequired, requireRole('admin'), async (req,res)=>{
  try{
    const demandaId = req.params.id;
    const { status } = req.body || {};
    if (!status) return res.status(400).json({ error:'missing status' });

    // pega demanda
    const dem = await get(db, `SELECT * FROM demandas WHERE id=?`, [demandaId]);
    if(!dem) return res.status(404).json({ error:'not found' });

    await run(db, `UPDATE demandas SET status=? WHERE id=?`, [status, demandaId]);

    // histórico + notificação pro dono
    await pushHistorico(dem.user_id,
      'demanda_status',
      `Status da demanda #${demandaId} atualizado para '${status}'`,
      'demanda',
      demandaId
    );
    await pushNotificacao(dem.user_id,
      `Sua demanda #${demandaId} agora está '${status}'.`
    );

    res.json({ ok:true });
  }catch(err){
    console.error('status demanda error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// =============================
// Agendamentos
// =============================

// Listar agendamentos
app.get('/api/agendamentos', authRequired, async (req,res)=>{
  try{
    if (req.user.role === 'admin') {
      // admin vê todos + info do usuário
      const rows = await all(db, `
        SELECT a.id, a.servico, a.data, a.hora, a.obs, a.status, a.created_at,
               u.name as user_name, u.email as user_email
        FROM agendamentos a
        LEFT JOIN users u ON u.id = a.user_id
        ORDER BY a.created_at DESC
      `);
      return res.json(rows);
    } else {
      // cidadão vê só os seus
      const rows = await all(db, `
        SELECT id, servico, data, hora, obs, status, created_at
        FROM agendamentos
        WHERE user_id=?
        ORDER BY created_at DESC
      `, [req.user.id]);
      return res.json(rows);
    }
  }catch(err){
    console.error('get agendamentos error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// Criar agendamento (cidadão)
app.post('/api/agendamentos', authRequired, requireRole('cidadao'), async (req,res)=>{
  try{
    const { servico, data, hora, obs } = req.body || {};
    if(!servico || !data){
      return res.status(400).json({ error:'missing fields' });
    }
    const created_at = nowISO();
    const status = 'pendente';

    const result = await run(
      db,
      `INSERT INTO agendamentos (user_id,servico,data,hora,obs,status,created_at)
       VALUES (?,?,?,?,?,?,?)`,
      [req.user.id, servico || '', data || '', hora || '', obs || '', status, created_at]
    );
    const agId = result.lastID;

    // histórico + notificação pro cidadão
    await pushHistorico(req.user.id,
      'agendamento',
      `Agendamento #${agId} criado com status '${status}'`,
      'agendamento',
      agId
    );

    // notifica admins
    await notifyAllAdmins(`Novo agendamento #${agId} solicitado por ${req.user.name}`);

    res.json({ ok:true, agendamento_id: agId });
  }catch(err){
    console.error('post agendamento error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// Atualizar status agendamento (admin)
app.post('/api/agendamentos/:id/status', authRequired, requireRole('admin'), async (req,res)=>{
  try{
    const agId = req.params.id;
    const { status } = req.body || {};
    if(!status) return res.status(400).json({ error:'missing status' });

    const ag = await get(db, `SELECT * FROM agendamentos WHERE id=?`, [agId]);
    if(!ag) return res.status(404).json({ error:'not found' });

    await run(db, `UPDATE agendamentos SET status=? WHERE id=?`, [status, agId]);

    // histórico + notificação para o dono
    await pushHistorico(ag.user_id,
      'agendamento_status',
      `Status do agendamento #${agId} atualizado para '${status}'`,
      'agendamento',
      agId
    );
    await pushNotificacao(ag.user_id,
      `Seu agendamento #${agId} agora está '${status}'.`
    );

    res.json({ ok:true });
  }catch(err){
    console.error('status agendamento error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// =============================
// Notificações
// =============================
app.get('/api/notificacoes', authRequired, async (req,res)=>{
  try{
    const rows = await all(db,
      `SELECT id, mensagem, lida, timestamp
       FROM notificacoes
       WHERE user_id=?
       ORDER BY timestamp DESC
       LIMIT 50`,
      [req.user.id]
    );
    res.json(rows);
  }catch(err){
    console.error('get notificacoes error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// =============================
// Histórico
// =============================
app.get('/api/historico', authRequired, async (req,res)=>{
  try{
    if (req.user.role === 'admin') {
      const rows = await all(db, `
        SELECT h.id, h.tipo, h.mensagem, h.ref_tipo, h.ref_id,
               h.timestamp,
               u.name AS user_name, u.email AS user_email
        FROM historico h
        LEFT JOIN users u ON u.id = h.user_id
        ORDER BY h.timestamp DESC
        LIMIT 200
      `);
      return res.json(rows);
    } else {
      const rows = await all(db, `
        SELECT id, tipo, mensagem, ref_tipo, ref_id, timestamp
        FROM historico
        WHERE user_id=?
        ORDER BY timestamp DESC
        LIMIT 200
      `, [req.user.id]);
      return res.json(rows);
    }
  }catch(err){
    console.error('get historico error', err);
    res.status(500).json({ error:'internal error' });
  }
});

// =============================
// Healthcheck
// =============================
app.get('/api/health', (req,res)=>{
  res.json({ ok:true, time: nowISO() });
});

// =============================
// Servir arquivos estáticos do front e uploads
// =============================

// frontend
app.use(express.static(FRONTEND_DIR));
// uploads públicos
app.use('/uploads', express.static(UPLOADS_DIR));

// rota raiz -> login.html (ou home se quiser)
app.get('/', (req,res)=>{
  res.sendFile(path.join(FRONTEND_DIR, 'login.html'));
});

// =============================
// Start
// =============================
initDb().then(()=>{
  const PORT = process.env.PORT || 3333;
  app.listen(PORT, ()=>{
    console.log('[WebCidadao] Backend rodando em http://localhost:'+PORT);
    console.log('Frontend servido de', FRONTEND_DIR);
  });
}).catch(err=>{
  console.error('Falha ao inicializar DB', err);
  process.exit(1);
});
