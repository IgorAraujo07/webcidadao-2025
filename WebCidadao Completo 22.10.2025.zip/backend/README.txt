
WebCidadão backend (added)

Files:
- server.js : Express server using SQLite (db at ./data/webcidadao.db)
- package.json : npm dependencies

How to run:
1) Open a terminal and go to the backend folder:
   cd backend
2) Install dependencies:
   npm install
3) Start server:
   node server.js
4) The server will run on http://localhost:3333 by default

Notes:
- A ready SQLite DB file is included at backend/data/webcidadao.db with basic tables and sample data.
- Uploaded images will be saved to backend/uploads and served at /uploads/<filename>
- Change SECRET in server.js before using in production.
