// Simple Express backend for WebCidadão using SQLite.
// To run:
// 1) cd backend
// 2) npm install
// 3) node server.js
//
// The SQLite DB file is included as data/webcidadao.db

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const multer = require('multer');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const fs = require('fs');

const SECRET = 'change_this_secret_for_prod';
const DB_PATH = path.join(__dirname, 'data', 'webcidadao.db');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ensure data folder exists
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);

// open database
const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('Failed to open DB:', err);
    process.exit(1);
  }
  console.log('Connected to SQLite DB at', DB_PATH);
});

// multer for image uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'uploads'));
  },
  filename: function (req, file, cb) {
    const unique = Date.now() + '-' + Math.round(Math.random()*1E9);
    cb(null, unique + '-' + file.originalname.replace(/\s+/g,'_'));
  }
});
const upload = multer({ storage });

// simple auth helpers
function generateToken(user) {
  return jwt.sign({ id: user.id, name: user.name, email: user.email }, SECRET, { expiresIn: '7d' });
}

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'no token' });
  const parts = auth.split(' ');
  if (parts.length !== 2) return res.status(401).json({ error: 'invalid token' });
  const token = parts[1];
  jwt.verify(token, SECRET, (err, payload) => {
    if (err) return res.status(401).json({ error: 'invalid token' });
    req.user = payload;
    next();
  });
}

// Auth routes
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email and password required' });
  db.get('SELECT id FROM users WHERE email = ?', [email], async (err, row) => {
    if (err) return res.status(500).json({ error: 'db error' });
    if (row) return res.status(400).json({ error: 'user exists' });
    const hash = await bcrypt.hash(password, 10);
    db.run('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)', [name||'', email, hash], function(err) {
      if (err) return res.status(500).json({ error: 'insert error' });
      const user = { id: this.lastID, name: name||'', email };
      const token = generateToken(user);
      res.json({ user, token });
    });
  });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email and password required' });
  db.get('SELECT id, name, email, password_hash FROM users WHERE email = ?', [email], async (err, row) => {
    if (err) return res.status(500).json({ error: 'db error' });
    if (!row) return res.status(400).json({ error: 'user not found' });
    const ok = await bcrypt.compare(password, row.password_hash);
    if (!ok) return res.status(400).json({ error: 'invalid credentials' });
    const user = { id: row.id, name: row.name, email: row.email };
    const token = generateToken(user);
    res.json({ user, token });
  });
});

// Demanda endpoints
app.get('/api/demandas', (req, res) => {
  db.all('SELECT d.*, u.name as author_name FROM demandas d LEFT JOIN users u ON u.id = d.user_id ORDER BY d.created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'db error' });
    res.json(rows);
  });
});

app.get('/api/demandas/:id', (req, res) => {
  const id = req.params.id;
  db.get('SELECT d.*, u.name as author_name FROM demandas d LEFT JOIN users u ON u.id = d.user_id WHERE d.id = ?', [id], (err, row) => {
    if (err) return res.status(500).json({ error: 'db error' });
    if (!row) return res.status(404).json({ error: 'not found' });
    // fetch images
    db.all('SELECT * FROM images WHERE demanda_id = ?', [id], (err2, imgs) => {
      if (err2) return res.status(500).json({ error: 'db error' });
      row.images = imgs;
      res.json(row);
    });
  });
});

app.post('/api/demandas', upload.array('images', 6), (req, res) => {
  // accept form-data with fields: title, category, priority, description, user_id (optional)
  const { title, category, priority, description, user_id } = req.body;
  const uid = user_id ? Number(user_id) : null;
  const created_at = new Date().toISOString();
  db.run('INSERT INTO demandas (user_id, title, category, priority, description, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [uid, title, category, priority||'Média', description||'', 'Aberta', created_at], function(err) {
      if (err) return res.status(500).json({ error: 'insert error' });
      const demandaId = this.lastID;
      // save images rows
      const files = req.files || [];
      files.forEach(file => {
        const rel = '/uploads/' + path.basename(file.path);
        db.run('INSERT INTO images (demanda_id, path) VALUES (?, ?)', [demandaId, rel]);
      });
      db.get('SELECT * FROM demandas WHERE id = ?', [demandaId], (err2, row) => {
        res.json(row);
      });
    });
});

// simple admin action to change status
app.post('/api/demandas/:id/status', authMiddleware, (req, res) => {
  const id = req.params.id;
  const { status } = req.body;
  db.run('UPDATE demandas SET status = ? WHERE id = ?', [status, id], function(err) {
    if (err) return res.status(500).json({ error: 'update error' });
    res.json({ success: true });
  });
});

// serve a health endpoint
app.get('/api/health', (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

const PORT = process.env.PORT || 3333;
app.listen(PORT, () => console.log('Server listening on', PORT));