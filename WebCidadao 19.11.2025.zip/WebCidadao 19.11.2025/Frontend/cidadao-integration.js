
// cidadao-integration.js
// Conecta Área do Cidadão ao backend real (demandas, agendamentos, notificações)
// sem remover nada do JS original.

(function(){
document.addEventListener("DOMContentLoaded", async ()=>{
  const sess = window.wcRequireRole && window.wcRequireRole('cidadao');
  if(!sess) return;
  const token = window.wcGetToken ? window.wcGetToken() : "";

  function authHeaders(extra){
    return Object.assign({}, extra||{}, {
      "Authorization": "Bearer " + token
    });
  }

  function fmtDate(s){
    if(!s) return "";
    const d = new Date(s);
    if(isNaN(d.getTime())) return s;
    return d.toLocaleString();
  }

  // Preenche nome do cidadão na sidebar
  (function(){
    const u = window.wcGetUser ? window.wcGetUser() : null;
    const nomeEl = document.getElementById("cidadao-nome");
    if(u && nomeEl){
      nomeEl.textContent = u.name || u.nome || u.email || "";
    }
  })();

  // === DEMANDAS ===
  async function loadDemandas(){
    try{
      const r = await fetch("/api/demandas", { headers: authHeaders() });
      if(!r.ok) { console.warn("Falha loadDemandas", await r.text()); return; }
      const demandas = await r.json();

      const wrap = document.getElementById("lista-demandas");
      if(wrap){
        wrap.innerHTML = demandas.map(d => `
          <div class="card" data-id="${d.id}">
            <div class="card-body">
              <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                <div>
                  <strong>#${d.id}</strong> — ${d.title||''}<br>
                  <small class="muted">${d.category||''}</small>
                </div>
                <div style="text-align:right;">
                  <span class="badge" data-status="${d.status||''}">${d.status||''}</span><br>
                  <small class="muted">${fmtDate(d.created_at)}</small>
                </div>
              </div>
              ${d.description?`<div style="margin-top:8px;">${d.description}</div>`:''}
              ${d.images && d.images.length ? `
                <div style="margin-top:8px;">
                  ${d.images.map(img => `<a href="${img}" target="_blank">📎</a>`).join(" ")}
                </div>` : ''}
            </div>
          </div>
        `).join("");
      }

      // KPIs
      const abertas = demandas.filter(x => (x.status||'').toLowerCase()==='aberta').length;
      const conclu = demandas.filter(x => (x.status||'').toLowerCase().includes('resol')).length;

      const kAbertas = document.getElementById("kpi-abertas");
      if(kAbertas) kAbertas.textContent = abertas;
      const kAtendidas = document.getElementById("kpi-atendidas");
      if(kAtendidas) kAtendidas.textContent = conclu;
    }catch(e){
      console.warn("Erro loadDemandas:", e);
    }
  }

  // interceptar envio de nova demanda e mandar pro backend
  (function(){
    const formDem = document.getElementById("form-demanda");
    if(!formDem) return;
    formDem.addEventListener("submit", async (ev)=>{
      try{
        const fd = new FormData(formDem);
        const resp = await fetch("/api/demandas", {
          method:"POST",
          headers: authHeaders(),
          body: fd
        });
        if(!resp.ok){
          console.warn("Falha ao enviar demanda backend", await resp.text());
        }
        setTimeout(loadDemandas, 400);
      }catch(e){
        console.warn("Erro submit demanda backend:", e);
      }
    }, true); // capture
  })();

  // === AGENDAMENTOS ===
  async function loadAgendamentos(){
    try{
      const r = await fetch("/api/agendamentos", { headers: authHeaders() });
      if(!r.ok){ console.warn("Falha loadAgendamentos", await r.text()); return; }
      const ags = await r.json();

      const cont = document.getElementById("lista-agendamentos");
      if(cont){
        cont.innerHTML = ags.map(a=>`
          <div class="card" data-id="${a.id}">
            <div class="card-body">
              <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                <div>
                  <strong>${a.servico||''}</strong><br>
                  <small>${a.data||''} ${a.hora||''}</small>
                </div>
                <div style="text-align:right;">
                  <span class="badge">${a.status||''}</span><br>
                  <small class="muted">${fmtDate(a.created_at)}</small>
                </div>
              </div>
              ${a.obs?`<div style="margin-top:8px;">${a.obs}</div>`:''}
            </div>
          </div>
        `).join("");
      }

      const kAg = document.getElementById("kpi-agendamentos");
      if(kAg) kAg.textContent = ags.length;
    }catch(e){
      console.warn("Erro loadAgendamentos:", e);
    }
  }

  // interceptar envio de novo agendamento
  (function(){
    const formAg = document.getElementById("form-agendamento");
    if(!formAg) return;
    formAg.addEventListener("submit", async (ev)=>{
      try{
        const fd = new FormData(formAg);
        const payload = {
          servico: fd.get("servico") || "",
          data: fd.get("data") || "",
          hora: fd.get("hora") || "",
          obs: fd.get("observacoes") || ""
        };
        const resp = await fetch("/api/agendamentos", {
          method:"POST",
          headers: authHeaders({ "Content-Type":"application/json" }),
          body: JSON.stringify(payload)
        });
        if(!resp.ok){
          console.warn("Falha ao enviar agendamento backend", await resp.text());
        }
        setTimeout(loadAgendamentos, 400);
      }catch(e){
        console.warn("Erro submit agendamento backend:", e);
      }
    }, true); // capture
  })();

  // === NOTIFICAÇÕES ===
  async function loadNotificacoes(){
    try{
      const r = await fetch("/api/notificacoes", { headers: authHeaders() });
      if(!r.ok){ console.warn("Falha loadNotificacoes", await r.text()); return; }
      const notifs = await r.json();

      const list = document.getElementById("lista-notificacoes");
      if(list){
        list.innerHTML = notifs.map(n=>`
          <div class="notif-item small">
            <div>${n.mensagem}</div>
            <div class="muted">${fmtDate(n.timestamp)}</div>
          </div>
        `).join("");
      }
    }catch(e){
      console.warn("Erro loadNotificacoes:", e);
    }
  }


  // === PERFIL (atualizar nome/senha) ===
  (function(){
    const form = document.getElementById('form-perfil');
    if(!form) return;

    const nomeEl = form.querySelector('input[name="nome"]');
    const emailEl = form.querySelector('input[name="email"]');

    // preencher com dados atuais, se existirem
    if(sess && sess.user){
      if(nomeEl) nomeEl.value = sess.user.name || '';
      if(emailEl) emailEl.value = sess.user.email || '';
    }

    form.addEventListener('submit', async function(ev){
      ev.preventDefault();
      const payload = {
        name: nomeEl ? nomeEl.value.trim() : undefined,
        currentPassword: form.querySelector('input[name="senha_atual"]')?.value || undefined,
        newPassword: form.querySelector('input[name="nova_senha"]')?.value || undefined
      };

      try{
        const resp = await fetch('/api/auth/me',{
          method:'PUT',
          headers: authHeaders({ 'Content-Type':'application/json' }),
          body: JSON.stringify(payload)
        });
        if(!resp.ok){
          alert('Falha ao atualizar perfil');
          console.warn('update perfil', await resp.text());
          return;
        }
        const data = await resp.json();
        if(data && data.user){
          // atualizar sessão em localStorage
          const auth = JSON.parse(localStorage.getItem('wc.auth') || '{}');
          auth.nome = data.user.name;
          auth.usuario = data.user.email;
          localStorage.setItem('wc.auth', JSON.stringify(auth));
          alert('Perfil atualizado com sucesso!');
        }else{
          alert('Perfil atualizado.');
        }
        form.reset();
      }catch(e){
        console.warn('Erro update perfil:', e);
        alert('Erro ao atualizar perfil.');
      }
    });
  })();


  await loadDemandas();
  await loadAgendamentos();
  await loadNotificacoes();
});
})();
