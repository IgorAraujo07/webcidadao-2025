
// cadastro-integration.js
// Substitui a função handleSignup do seu front para também criar
// o usuário de verdade no backend e já logar.

(function(){
window.handleSignup = async function(e){
  e.preventDefault();

  try{
    const nomeEl = document.getElementById('nome');
    const emailEl = document.getElementById('email');
    const senhaEl = document.getElementById('senha');
    const perfilEl = document.getElementById('perfil');
    const confirmEl = document.getElementById('confirm');
    const admKeyEl = document.getElementById('adm-key');

    const nome = nomeEl ? nomeEl.value.trim() : "";
    const email = emailEl ? emailEl.value.trim() : "";
    const senha = senhaEl ? senhaEl.value : "";
    const perfil = perfilEl ? perfilEl.value : "cidadao";
    const confirm = confirmEl ? confirmEl.value : "";
    const admKey = admKeyEl ? admKeyEl.value.trim() : "";

    // mesmas validações do seu código antigo
    if(!nome || !email || !senha){
      alert("Preencha todos os campos obrigatórios.");
      return false;
    }

    const ADMIN_CODE = 'WC-ADMIN-2025';
    if (perfil === 'admin'){
      if (!admKey || admKey !== ADMIN_CODE){
        alert('Código de administrador inválido.');
        return false;
      }
    }

    if (senha !== confirm){
      alert('As senhas não coincidem.');
      return false;
    }

    // cria usuário no backend
    const r = await fetch("/api/auth/register", {
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({
        name: nome,
        email: email,
        password: senha,
        role: perfil
      })
    });

    if(!r.ok){
      alert("Erro ao cadastrar no servidor.");
      console.warn(await r.text());
      return false;
    }

    const data = await r.json();
    // salva sessão no storage compatível
    window.wcSaveSession(data);

    alert('Conta criada com sucesso!');

    if (data.user && data.user.role === 'admin'){
      window.location.href = 'admin.html';
    } else {
      window.location.href = 'cidadao.html';
    }
    return false;
  }catch(err){
    console.error("cadastro-integration erro:", err);
    alert("Erro inesperado ao cadastrar.");
    return false;
  }
};
})();
