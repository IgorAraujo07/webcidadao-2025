
// wc-api.js
// Camada de integração compatível com seu front antigo (localStorage)
// e o backend Node/Express + SQLite.
// NÃO remove nada do que já existe.

(function(){
  const API_BASE = ""; // mesmo host do backend

  // salva sessão recebida do backend (/api/auth/login ou /api/auth/register)
  window.wcSaveSession = function (data){
    try{
      if(data && data.token){
        localStorage.setItem("wc.token", data.token);
      }
      if(data && data.user){
        localStorage.setItem("wc.user", JSON.stringify(data.user));

        // Compatibilidade com seu formato antigo wc.auth
        const legacyAuth = {
          perfil: data.user.role,
          usuario: data.user.email,
          nome: data.user.name || data.user.email,
          loginAt: Date.now()
        };
        localStorage.setItem("wc.auth", JSON.stringify(legacyAuth));
      }
    }catch(e){
      console.warn("Falha ao salvar sessão:", e);
    }
  };

  window.wcGetToken = function(){
    return localStorage.getItem("wc.token") || "";
  };

  window.wcGetUser = function(){
    try {
      return JSON.parse(localStorage.getItem("wc.user") || "null");
    } catch(e){
      return null;
    }
  };

  // Garante que o usuário esteja logado e, se role exigido, que combine.
  // Se não estiver ok, redireciona para login.
  window.wcRequireRole = function(expectedRole){
    const user = window.wcGetUser();
    const token = window.wcGetToken();
    if(!user || !token){
        window.location.href = "login.html";
        return null;
    }
    if(expectedRole && user.role !== expectedRole){
        // manda pro painel certo
        window.location.href = (user.role === "admin" ? "admin.html" : "cidadao.html");
        return null;
    }
    return { user, token };
  };

})();
