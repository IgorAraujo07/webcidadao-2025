// backend-bridge.js
// Sincroniza dados reais do backend (Node + SQLite) com o LocalStorage,
// para reaproveitar as telas antigas (demandas.html, relatórios, etc.)
// sem quebrar nada do que já existia.

(function(){
  document.addEventListener("DOMContentLoaded", async ()=>{
    if (!window.wcGetToken || !window.wcGetUser) return;
    const user = window.wcGetUser();
    const token = window.wcGetToken();
    if (!token) return;

    function headers(extra){
      return Object.assign({}, extra||{}, {
        "Authorization": "Bearer " + token
      });
    }

    async function syncDemandas(){
      try{
        const r = await fetch("/api/demandas", { headers: headers() });
        if (!r.ok){
          console.warn("backend-bridge demandas:", await r.text());
          return;
        }
        const arr = await r.json();
        if (!Array.isArray(arr)) return;

        const mapped = arr.map(d => ({
          id: d.id,
          titulo: d.title || "",
          categoria: d.category || "",
          prioridade: d.priority || "Média",
          status: d.status || "Aberta",
          descricao: d.description || "",
          criadoEm: d.created_at || d.createdAt || new Date().toISOString(),
          autor: d.user_name || d.user || ""
        }));

        try {
          localStorage.setItem("wc.demands.all", JSON.stringify(mapped));
          if (user && user.id){
            localStorage.setItem("wc.demands."+user.id, JSON.stringify(mapped));
          }
        } catch(e){
          console.warn("backend-bridge localStorage error:", e);
        }
      }catch(e){
        console.warn("backend-bridge syncDemandas erro:", e);
      }
    }

    await syncDemandas();
    // Atualiza de tempos em tempos enquanto a sessão estiver ativa
    setInterval(syncDemandas, 60000);
  });
})();
