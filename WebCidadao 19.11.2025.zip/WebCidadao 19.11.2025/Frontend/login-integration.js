
// login-integration.js
// Injeta login REAL no backend, mas SEM apagar seu script antigo.
// A ideia: no submit, antes do seu redirecionamento demo,
// tentamos fazer /api/auth/login e guardar wc.token + wc.user.

(function(){
document.addEventListener("DOMContentLoaded", ()=>{
  const form = document.getElementById("loginForm");
  if(!form) return;

  form.addEventListener("submit", async (ev)=>{
    try{
      // pegar perfil, email, senha de forma genérica
      const perfilSel = form.querySelector("#perfil");
      const perfil = perfilSel ? perfilSel.value : "";

      const emailInput = form.querySelector("input[type='email'], input[name='email'], #usuario");
      const passInput  = form.querySelector("input[type='password'], input[name='senha'], #senha");

      const email = emailInput ? emailInput.value.trim() : "";
      const password = passInput ? passInput.value : "";

      if(!email || !password){
        console.warn("login-integration: faltando email/senha");
        return;
      }

      // tenta autenticar no backend
      const r = await fetch("/api/auth/login", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ email, password })
      });

      if(r.ok){
        const data = await r.json();
        // guarda token + user para as telas protegidas
        window.wcSaveSession(data);
        console.log("Sessão salva via backend:", data);
      } else {
        console.warn("Backend recusou login (mas front local continua):", await r.text());
      }

    }catch(e){
      console.warn("Falha na integração de login:", e);
    }
  }, true); // capture=true -> roda antes do listener antigo
});
})();
