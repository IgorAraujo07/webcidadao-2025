
// admin-integration.js
// Preenche o painel Admin com dados REAIS do backend e permite atualizar status.
// Não remove nada do que já existe (bridge-demanda.js, etc.).

(function(){
document.addEventListener("DOMContentLoaded", async ()=>{
  const sess = window.wcRequireRole && window.wcRequireRole('admin');
  if(!sess) return;
  const token = window.wcGetToken ? window.wcGetToken() : "";

  function authHeaders(extra){
    return Object.assign({}, extra||{}, {
      "Authorization": "Bearer " + token
    });
  }
  function fmtDate(s){
    if(!s) return "";
    const d = new Date(s);
    if(isNaN(d.getTime())) return s;
    return d.toLocaleString();
  }

  const demandasBody = document.querySelector("#tb-demandas tbody");
  const agBody = document.querySelector("#tb-agendamentos tbody");

  async function loadDemandas(){
    try{
      const r = await fetch("/api/demandas", { headers: authHeaders() });
      if(!r.ok){ console.warn("Falha loadDemandas admin", await r.text()); return; }
      const demandas = await r.json();

      if(demandasBody){
        demandasBody.innerHTML = demandas.map(d=>`
          <tr data-id="${d.id}">
            <td>#${d.id}</td>
            <td>
              <div>${d.title||''}</div>
              <small class="muted">${d.category||''}</small>
            </td>
            <td>${d.user_name||''}<br><small class="muted">${d.user_email||''}</small></td>
            <td><span class="badge">${d.status||''}</span></td>
            <td>
              <button class="btn small" data-action="status" data-status="em_andamento">Em andamento</button>
              <button class="btn small" data-action="status" data-status="resolvida">Resolver</button>
            </td>
          </tr>
        `).join("");
      }

      // KPIs
      const abertas = demandas.filter(x=>(x.status||'').toLowerCase()==='aberta').length;
      const andamento = demandas.filter(x=>(x.status||'').toLowerCase().includes('andamento')).length;
      const concluidas = demandas.filter(x=>(x.status||'').toLowerCase().includes('resol') || (x.status||'').toLowerCase().includes('conclu')).length;

      const kAbertas = document.getElementById("kpi-abertas");
      if(kAbertas) kAbertas.textContent = abertas;
      const kAndamento = document.getElementById("kpi-andamento");
      if(kAndamento) kAndamento.textContent = andamento;
      const kConcluidas = document.getElementById("kpi-concluidas");
      if(kConcluidas) kConcluidas.textContent = concluidas;
      const kPrazoHoje = document.getElementById("kpi-prazo-hoje");
      if(kPrazoHoje) kPrazoHoje.textContent = "0"; // backend atual não controla prazo, então deixamos 0
    }catch(e){
      console.warn("Erro loadDemandas admin:", e);
    }
  }

  async function loadAgendamentos(){
    try{
      const r = await fetch("/api/agendamentos", { headers: authHeaders() });
      if(!r.ok){ console.warn("Falha loadAgendamentos admin", await r.text()); return; }
      const ags = await r.json();

      if(agBody){
        agBody.innerHTML = ags.map(a=>`
          <tr data-id="${a.id}">
            <td>#${a.id}</td>
            <td>${a.user_name||''}<br><small class="muted">${a.user_email||''}</small></td>
            <td>${a.servico||''}</td>
            <td>${a.data||''}</td>
            <td>${a.hora||''}</td>
            <td>${a.obs||''}</td>
            <td>
              <button class="btn small" data-action="ag-status" data-status="confirmado">Confirmar</button>
              <button class="btn small" data-action="ag-status" data-status="cancelado">Cancelar</button><br>
              <small class="muted">${a.status||''}</small>
            </td>
          </tr>
        `).join("");
      }

      const kAg = document.getElementById("kpi-ag-admin");
      if(kAg) kAg.textContent = ags.length;
    }catch(e){
      console.warn("Erro loadAgendamentos admin:", e);
    }
  }

  // Delegação de clique para atualizar status
  if(demandasBody){
    demandasBody.addEventListener("click", async (ev)=>{
      const btn = ev.target.closest("button[data-action='status']");
      if(!btn) return;
      const tr = btn.closest("tr[data-id]");
      if(!tr) return;
      const id = tr.getAttribute("data-id");
      const newStatus = btn.getAttribute("data-status");

      try{
        const resp = await fetch("/api/demandas/"+id+"/status", {
          method:"POST",
          headers: authHeaders({"Content-Type":"application/json"}),
          body: JSON.stringify({ status:newStatus })
        });
        if(!resp.ok){
          alert("Falha ao atualizar status da demanda");
          console.warn(await resp.text());
          return;
        }
        await loadDemandas();
      }catch(e){
        console.warn("Erro atualizar demanda:", e);
      }
    });
  }

  if(agBody){
    agBody.addEventListener("click", async (ev)=>{
      const btn = ev.target.closest("button[data-action='ag-status']");
      if(!btn) return;
      const tr = btn.closest("tr[data-id]");
      if(!tr) return;
      const id = tr.getAttribute("data-id");
      const newStatus = btn.getAttribute("data-status");

      try{
        const resp = await fetch("/api/agendamentos/"+id+"/status", {
          method:"POST",
          headers: authHeaders({"Content-Type":"application/json"}),
          body: JSON.stringify({ status:newStatus })
        });
        if(!resp.ok){
          alert("Falha ao atualizar status do agendamento");
          console.warn(await resp.text());
          return;
        }
        await loadAgendamentos();
      }catch(e){
        console.warn("Erro atualizar agendamento:", e);
      }
    });
  }

  await loadDemandas();
  await loadAgendamentos();
});
})();
