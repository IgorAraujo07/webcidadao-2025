const request = require('supertest');
const { app, initDb, db } = require('../server');

let tokenUsuario;
let emailUsuario;

beforeAll(async () => {
  await initDb();

  emailUsuario = `perfil.${Date.now()}@cidadao.local`;

  const registro = await request(app)
    .post('/api/auth/register')
    .send({
      name: 'Usuario Perfil Jest',
      email: emailUsuario,
      password: 'senhaPerfil123',
      role: 'cidadao'
    });

  tokenUsuario = registro.body.token;
});

afterAll(done => {
  db.close(done);
});

describe('Atualizacao de perfil e senha', () => {
  test('atualiza apenas o nome do usuario logado', async () => {
    const res = await request(app)
      .put('/api/auth/me')
      .set('Authorization', `Bearer ${tokenUsuario}`)
      .send({
        name: 'Usuario Perfil Atualizado'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('ok', true);
    expect(res.body).toHaveProperty('user');
    expect(res.body.user.name).toBe('Usuario Perfil Atualizado');
  });

  test('nao permite trocar senha com currentPassword incorreta', async () => {
    const res = await request(app)
      .put('/api/auth/me')
      .set('Authorization', `Bearer ${tokenUsuario}`)
      .send({
        currentPassword: 'senhaErrada',
        newPassword: 'novaSenha123'
      });

    expect(res.statusCode).toBe(400);
    expect(res.body).toHaveProperty('error');
  });

  test('permite trocar senha com currentPassword correta e login com nova senha funciona', async () => {
    const res = await request(app)
      .put('/api/auth/me')
      .set('Authorization', `Bearer ${tokenUsuario}`)
      .send({
        currentPassword: 'senhaPerfil123',
        newPassword: 'novaSenhaOk123'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('ok', true);

    const loginNovo = await request(app)
      .post('/api/auth/login')
      .send({
        email: emailUsuario,
        password: 'novaSenhaOk123'
      });

    expect(loginNovo.statusCode).toBe(200);
    expect(loginNovo.body).toHaveProperty('token');
    expect(loginNovo.body).toHaveProperty('user');
  });
});
