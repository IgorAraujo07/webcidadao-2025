const request = require('supertest');
const { app, initDb, db } = require('../server');

let tokenCidadao;
let tokenAdmin;

beforeAll(async () => {
  await initDb();

  const loginCid = await request(app)
    .post('/api/auth/login')
    .send({ email: 'cidadao@demo.com', password: '12345' });

  tokenCidadao = loginCid.body.token;

  const loginAdm = await request(app)
    .post('/api/auth/login')
    .send({ email: 'admin@demo.com', password: '12345' });

  tokenAdmin = loginAdm.body.token;

  const novaDemanda = await request(app)
    .post('/api/demandas')
    .set('Authorization', `Bearer ${tokenCidadao}`)
    .field('titulo', 'Demanda para historico')
    .field('categoria', 'teste')
    .field('descricao', 'gera historico e notificacao')
    .field('prioridade', 'baixa');

  const demandaId = novaDemanda.body.demanda_id;

  await request(app)
    .post(`/api/demandas/${demandaId}/status`)
    .set('Authorization', `Bearer ${tokenAdmin}`)
    .send({ status: 'em_andamento' });
});

afterAll(done => {
  db.close(done);
});

describe('Historico e notificacoes em perspectiva de admin', () => {
  test('admin visualiza historico com dados de usuario', async () => {
    const res = await request(app)
      .get('/api/historico')
      .set('Authorization', `Bearer ${tokenAdmin}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);

    if (res.body.length > 0) {
      const item = res.body[0];
      expect(item).toHaveProperty('user_name');
      expect(item).toHaveProperty('user_email');
    }
  });

  test('cidadao visualiza notificacoes relacionadas as suas acoes', async () => {
    const res = await request(app)
      .get('/api/notificacoes')
      .set('Authorization', `Bearer ${tokenCidadao}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});
