const request = require('supertest');
const { app, initDb, db } = require('../server');

let tokenCidadao;
let tokenAdmin;
let demandaCriadaId;

beforeAll(async () => {
  await initDb();

  const loginCid = await request(app)
    .post('/api/auth/login')
    .send({ email: 'cidadao@demo.com', password: '12345' });

  tokenCidadao = loginCid.body.token;

  const loginAdm = await request(app)
    .post('/api/auth/login')
    .send({ email: 'admin@demo.com', password: '12345' });

  tokenAdmin = loginAdm.body.token;
});

afterAll(done => {
  db.close(done);
});

describe('Demandas - fluxo completo', () => {
  test('cidadão cria uma nova demanda', async () => {
    const res = await request(app)
      .post('/api/demandas')
      .set('Authorization', `Bearer ${tokenCidadao}`)
      .field('titulo', 'Buraco na rua principal')
      .field('categoria', 'Infraestrutura')
      .field('descricao', 'Há um buraco grande em frente à minha casa.')
      .field('prioridade', 'alta');

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('ok', true);
    expect(res.body).toHaveProperty('demanda_id');

    demandaCriadaId = res.body.demanda_id;
  });

  test('cidadão lista suas demandas', async () => {
    const res = await request(app)
      .get('/api/demandas')
      .set('Authorization', `Bearer ${tokenCidadao}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    // deve ter pelo menos 1 (a que acabou de criar)
    expect(res.body.length).toBeGreaterThanOrEqual(1);
  });

  test('admin lista todas as demandas', async () => {
    const res = await request(app)
      .get('/api/demandas')
      .set('Authorization', `Bearer ${tokenAdmin}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('admin atualiza status da demanda criada para em_andamento', async () => {
    const res = await request(app)
      .post(`/api/demandas/${demandaCriadaId}/status`)
      .set('Authorization', `Bearer ${tokenAdmin}`)
      .send({ status: 'em_andamento' });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('ok', true);
  });
});
