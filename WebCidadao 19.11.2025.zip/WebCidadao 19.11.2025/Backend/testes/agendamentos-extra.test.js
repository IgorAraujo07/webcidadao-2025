const request = require('supertest');
const { app, initDb, db } = require('../server');

let tokenCidadao;

beforeAll(async () => {
  await initDb();

  const loginCid = await request(app)
    .post('/api/auth/login')
    .send({ email: 'cidadao@demo.com', password: '12345' });

  tokenCidadao = loginCid.body.token;
});

afterAll(done => {
  db.close(done);
});

describe('Casos adicionais de agendamentos', () => {
  test('nao permite criar agendamento sem servico ou data', async () => {
    const res = await request(app)
      .post('/api/agendamentos')
      .set('Authorization', `Bearer ${tokenCidadao}`)
      .send({
        servico: '',
        data: '',
        hora: '09:00',
        obs: 'sem dados obrigatorios'
      });

    expect(res.statusCode).toBe(400);
    expect(res.body).toHaveProperty('error', 'missing fields');
  });

  test('permite criar agendamento minimo valido', async () => {
    const res = await request(app)
      .post('/api/agendamentos')
      .set('Authorization', `Bearer ${tokenCidadao}`)
      .send({
        servico: 'Atendimento basico',
        data: '2099-10-10'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('ok', true);
    expect(res.body).toHaveProperty('agendamento_id');
  });
});
