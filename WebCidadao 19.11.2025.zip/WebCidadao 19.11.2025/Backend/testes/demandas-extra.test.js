const request = require('supertest');
const { app, initDb, db } = require('../server');

let tokenCidadao;
let tokenAdmin;
let demandaId;

beforeAll(async () => {
  await initDb();

  // login cidadão demo
  const loginCid = await request(app)
    .post('/api/auth/login')
    .send({ email: 'cidadao@demo.com', password: '12345' });

  tokenCidadao = loginCid.body.token;

  // login admin demo
  const loginAdm = await request(app)
    .post('/api/auth/login')
    .send({ email: 'admin@demo.com', password: '12345' });

  tokenAdmin = loginAdm.body.token;

  // cria uma demanda para tentar detalhar depois
  const nova = await request(app)
    .post('/api/demandas')
    .set('Authorization', `Bearer ${tokenCidadao}`)
    .field('titulo', 'Demanda para teste de detalhes')
    .field('categoria', 'teste')
    .field('descricao', 'detalhes da demanda')
    .field('prioridade', 'alta');

  demandaId = nova.body.demanda_id;
});

afterAll(done => {
  db.close(done);
});

describe('Casos adicionais de demandas', () => {
  test('cidadao tenta ver detalhes da propria demanda', async () => {
    const res = await request(app)
      .get(`/api/demandas/${demandaId}`)
      .set('Authorization', `Bearer ${tokenCidadao}`);

    // aceitamos tanto 200 (detalhe funcionando) quanto 404 (nao implementado)
    expect([200, 404]).toContain(res.statusCode);

    if (res.statusCode === 200) {
      expect(res.body).toHaveProperty('id', demandaId);
      expect(res.body).toHaveProperty('title');
      expect(res.body).toHaveProperty('status');
    }
  });

  test('admin tenta ver detalhes da demanda com informacoes do cidadao', async () => {
    const res = await request(app)
      .get(`/api/demandas/${demandaId}`)
      .set('Authorization', `Bearer ${tokenAdmin}`);

    // idem: aceitamos 200 ou 404
    expect([200, 404]).toContain(res.statusCode);

    if (res.statusCode === 200) {
      expect(res.body).toHaveProperty('id', demandaId);
      expect(res.body).toHaveProperty('user_name');
      expect(res.body).toHaveProperty('user_email');
    }
  });

  test('detalhe de demanda inexistente retorna status 404', async () => {
    const res = await request(app)
      .get('/api/demandas/999999')
      .set('Authorization', `Bearer ${tokenAdmin}`);

    expect(res.statusCode).toBe(404);
    // alguns ambientes podem devolver corpo vazio, entao nao forçamos estrutura
  });
});
