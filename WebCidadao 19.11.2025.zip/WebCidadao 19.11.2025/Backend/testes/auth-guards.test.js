const request = require('supertest');
const { app, initDb, db } = require('../server');

let tokenCidadao;
let tokenAdmin;

beforeAll(async () => {
  await initDb();

  const loginCid = await request(app)
    .post('/api/auth/login')
    .send({ email: 'cidadao@demo.com', password: '12345' });

  tokenCidadao = loginCid.body.token;

  const loginAdm = await request(app)
    .post('/api/auth/login')
    .send({ email: 'admin@demo.com', password: '12345' });

  tokenAdmin = loginAdm.body.token;
});

afterAll(done => {
  db.close(done);
});

describe('Protecao de rotas e papeis de usuario', () => {
  test('nega acesso quando nao ha token', async () => {
    const res = await request(app).get('/api/demandas');

    expect(res.statusCode).toBe(401);
    expect(res.body).toHaveProperty('error', 'missing token');
  });

  test('nega acesso com token invalido', async () => {
    const res = await request(app)
      .get('/api/demandas')
      .set('Authorization', 'Bearer token.invalido');

    expect(res.statusCode).toBe(401);
    expect(res.body).toHaveProperty('error');
  });

  test('cidadao pode listar apenas as proprias demandas', async () => {
    const res = await request(app)
      .get('/api/demandas')
      .set('Authorization', `Bearer ${tokenCidadao}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('admin nao pode usar rota exclusiva de cidadao para criar demanda', async () => {
    const res = await request(app)
      .post('/api/demandas')
      .set('Authorization', `Bearer ${tokenAdmin}`)
      .field('titulo', 'Demanda criada por admin indevidamente')
      .field('categoria', 'teste')
      .field('descricao', 'nao deveria permitir')
      .field('prioridade', 'baixa');

    expect(res.statusCode).toBe(403);
    expect(res.body).toHaveProperty('error', 'forbidden');
  });

  test('admin nao pode usar rota exclusiva de cidadao para criar agendamento', async () => {
    const res = await request(app)
      .post('/api/agendamentos')
      .set('Authorization', `Bearer ${tokenAdmin}`)
      .send({
        servico: 'Servico teste admin',
        data: '2099-12-31',
        hora: '10:00',
        obs: 'nao deveria permitir'
      });

    expect(res.statusCode).toBe(403);
    expect(res.body).toHaveProperty('error', 'forbidden');
  });

  test('cidadao nao pode atualizar status de demanda', async () => {
    const nova = await request(app)
      .post('/api/demandas')
      .set('Authorization', `Bearer ${tokenCidadao}`)
      .field('titulo', 'Demanda para teste de permissao')
      .field('categoria', 'teste')
      .field('descricao', 'teste de status')
      .field('prioridade', 'media');

    const demandaId = nova.body.demanda_id;

    const res = await request(app)
      .post(`/api/demandas/${demandaId}/status`)
      .set('Authorization', `Bearer ${tokenCidadao}`)
      .send({ status: 'em_andamento' });

    expect(res.statusCode).toBe(403);
    expect(res.body).toHaveProperty('error', 'forbidden');
  });

  test('cidadao nao pode atualizar status de agendamento', async () => {
    const novo = await request(app)
      .post('/api/agendamentos')
      .set('Authorization', `Bearer ${tokenCidadao}`)
      .send({
        servico: 'Servico teste status',
        data: '2099-11-30',
        hora: '15:00',
        obs: 'teste'
      });

    const agendamentoId = novo.body.agendamento_id;

    const res = await request(app)
      .post(`/api/agendamentos/${agendamentoId}/status`)
      .set('Authorization', `Bearer ${tokenCidadao}`)
      .send({ status: 'confirmado' });

    expect(res.statusCode).toBe(403);
    expect(res.body).toHaveProperty('error', 'forbidden');
  });
});
