const request = require('supertest');
const { app, initDb, db } = require('../server');

let tokenCidadao;

beforeAll(async () => {
  await initDb();

  const loginCid = await request(app)
    .post('/api/auth/login')
    .send({ email: 'cidadao@demo.com', password: '12345' });

  tokenCidadao = loginCid.body.token;
});

afterAll(done => {
  db.close(done);
});

describe('Healthcheck e monitoramento', () => {
  test('healthcheck deve responder ok', async () => {
    const res = await request(app).get('/api/health');
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('ok', true);
  });

  test('notificações retornam lista (mesmo que vazia)', async () => {
    const res = await request(app)
      .get('/api/notificacoes')
      .set('Authorization', `Bearer ${tokenCidadao}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('histórico retorna lista (mesmo que vazia)', async () => {
    const res = await request(app)
      .get('/api/historico')
      .set('Authorization', `Bearer ${tokenCidadao}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});
