const request = require('supertest');
const { app, initDb, db } = require('../server');

let serverReady = false;

beforeAll(async () => {
  if (!serverReady) {
    await initDb(); // garante que tabelas e usuários demo existem
    serverReady = true;
  }
});

afterAll(done => {
  // fecha o banco depois dos testes
  db.close(done);
});

describe('Auth / Login / Perfil', () => {
  test('login deve falhar com credenciais inválidas', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'naoexiste@teste.com', password: 'errada' });

    expect(res.statusCode).toBe(401);
    expect(res.body).toHaveProperty('error');
  });

  test('login admin demo com credenciais corretas', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'admin@demo.com', password: '12345' });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('token');
    expect(res.body).toHaveProperty('user');
    expect(res.body.user.role).toBe('admin');
  });

  test('login cidadao demo com credenciais corretas e acesso ao /api/auth/me', async () => {
    const loginRes = await request(app)
      .post('/api/auth/login')
      .send({ email: 'cidadao@demo.com', password: '12345' });

    expect(loginRes.statusCode).toBe(200);
    const token = loginRes.body.token;
    expect(token).toBeDefined();

    const meRes = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${token}`);

    expect(meRes.statusCode).toBe(200);
    expect(meRes.body).toHaveProperty('user');
    expect(meRes.body.user.email).toBe('cidadao@demo.com');
  });

  test('registro de novo cidadão', async () => {
    const email = `teste.${Date.now()}@cidadao.local`;

    const res = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Cidadão Teste Jest',
        email,
        password: 'senha123',
        role: 'cidadao'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('token');
    expect(res.body.user.email).toBe(email);
    expect(res.body.user.role).toBe('cidadao');
  });

  test('recuperação de senha (forgot) retorna ok mesmo com email existente', async () => {
    const res = await request(app)
      .post('/api/auth/forgot')
      .send({ email: 'cidadao@demo.com' });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('ok', true);
  });
});
