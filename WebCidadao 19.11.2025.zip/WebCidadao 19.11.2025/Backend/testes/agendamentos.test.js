const request = require('supertest');
const { app, initDb, db } = require('../server');

let tokenCidadao;
let tokenAdmin;
let agendamentoId;

beforeAll(async () => {
  await initDb();

  const loginCid = await request(app)
    .post('/api/auth/login')
    .send({ email: 'cidadao@demo.com', password: '12345' });

  tokenCidadao = loginCid.body.token;

  const loginAdm = await request(app)
    .post('/api/auth/login')
    .send({ email: 'admin@demo.com', password: '12345' });

  tokenAdmin = loginAdm.body.token;
});

afterAll(done => {
  db.close(done);
});

describe('Agendamentos - fluxo completo', () => {
  test('cidadão cria agendamento', async () => {
    const res = await request(app)
      .post('/api/agendamentos')
      .set('Authorization', `Bearer ${tokenCidadao}`)
      .send({
        servico: 'Atendimento na secretaria',
        data: '2025-11-20',
        hora: '09:30',
        obs: 'Levar documentos pessoais'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('ok', true);
    expect(res.body).toHaveProperty('agendamento_id');

    agendamentoId = res.body.agendamento_id;
  });

  test('cidadão lista seus agendamentos', async () => {
    const res = await request(app)
      .get('/api/agendamentos')
      .set('Authorization', `Bearer ${tokenCidadao}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('admin lista todos os agendamentos', async () => {
    const res = await request(app)
      .get('/api/agendamentos')
      .set('Authorization', `Bearer ${tokenAdmin}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('admin atualiza status do agendamento para confirmado', async () => {
    const res = await request(app)
      .post(`/api/agendamentos/${agendamentoId}/status`)
      .set('Authorization', `Bearer ${tokenAdmin}`)
      .send({ status: 'confirmado' });

    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('ok', true);
  });
});
