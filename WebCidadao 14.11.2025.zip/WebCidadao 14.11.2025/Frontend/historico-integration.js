
// historico-integration.js
// Conecta a página de Histórico ao backend /api/historico (apenas admin).
(function(){
  document.addEventListener("DOMContentLoaded", async ()=>{
    if(!window.wcRequireRole) return;
    const sess = window.wcRequireRole('admin');
    if(!sess) return;
    const token = window.wcGetToken ? window.wcGetToken() : "";

    function authHeaders(extra){
      return Object.assign({}, extra||{}, {
        "Authorization": "Bearer " + token,
        "Content-Type": "application/json"
      });
    }

    const byId = (id)=> document.getElementById(id);
    const cont = byId('hist-container');
    const kpisBox = byId('hist-kpis');
    const selTipo = byId('hist-tipo');
    const selUser = byId('hist-user');
    const inpDe = byId('hist-de');
    const inpAte = byId('hist-ate');
    const btnRecarregar = byId('hist-recarregar');

    let raw = [];

    function fmtDate(iso){
      if(!iso) return '';
      const d = new Date(iso);
      if(!isFinite(d)) return iso;
      return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
    }

    function applyFilters(){
      const tipo = selTipo && selTipo.value || '';
      const userId = selUser && selUser.value || '';
      const de = inpDe && inpDe.value ? new Date(inpDe.value+'T00:00:00') : null;
      const ate = inpAte && inpAte.value ? new Date(inpAte.value+'T23:59:59') : null;

      let list = raw.slice();

      if(tipo){
        list = list.filter(h => (h.tipo||'') === tipo);
      }
      if(userId){
        list = list.filter(h => String(h.user_id||'') === userId);
      }
      if(de){
        list = list.filter(h => {
          const d = new Date(h.timestamp);
          return d >= de;
        });
      }
      if(ate){
        list = list.filter(h => {
          const d = new Date(h.timestamp);
          return d <= ate;
        });
      }

      // KPIs simples
      if(kpisBox){
        const total = list.length;
        const porTipo = {};
        for(const h of list){
          const t = h.tipo || 'evento';
          porTipo[t] = (porTipo[t]||0)+1;
        }
        kpisBox.innerHTML = `
          <div class="kpi"><strong>${total}</strong><span class="muted">Eventos</span></div>
          ${Object.keys(porTipo).slice(0,3).map(t=>`
            <div class="kpi"><strong>${porTipo[t]}</strong><span class="muted">${t}</span></div>
          `).join('')}
        `;
      }

      if(!cont) return;
      if(!list.length){
        cont.innerHTML = '<p class="muted">Nenhum evento encontrado para os filtros.</p>';
        return;
      }

      // agrupar por dia
      const byDay = {};
      for(const h of list){
        const d = new Date(h.timestamp);
        const key = isFinite(d) ? d.toISOString().slice(0,10) : 'sem-data';
        if(!byDay[key]) byDay[key]=[];
        byDay[key].push(h);
      }
      const days = Object.keys(byDay).sort().reverse();

      cont.innerHTML = days.map(day=>{
        const eventos = byDay[day].sort((a,b)=> a.timestamp < b.timestamp ? 1 : -1);
        const label = new Date(day+'T00:00:00').toLocaleDateString('pt-BR');
        return `
          <div class="hist-dia">${label}</div>
          <ul class="hist-list">
            ${eventos.map(ev=>`
              <li class="hist-item">
                <div class="hist-hora">${fmtDate(ev.timestamp).slice(11,16)}</div>
                <div class="hist-msg">
                  <div>${ev.mensagem || ''}</div>
                  <div class="hist-meta">
                    <span class="hist-badge">${ev.tipo || 'evento'}</span>
                    ${ev.user_name ? ` &mdash; ${ev.user_name} (${ev.user_email||''})` : ''}
                    ${ev.ref_tipo ? ` &middot; ref: ${ev.ref_tipo} #${ev.ref_id||''}` : ''}
                  </div>
                </div>
              </li>
            `).join('')}
          </ul>
        `;
      }).join('');
    }

    async function loadHistorico(){
      try{
        const r = await fetch('/api/historico', { headers: authHeaders() });
        if(!r.ok){
          console.warn('Falha ao carregar histórico', await r.text());
          return;
        }
        raw = await r.json();

        // preencher filtro de usuários
        if(selUser){
          const usuarios = {};
          raw.forEach(h=>{
            if(h.user_id && h.user_name){
              usuarios[h.user_id] = h.user_name;
            }
          });
          selUser.innerHTML = '<option value="">Todos</option>' +
            Object.keys(usuarios).map(id=>`<option value="${id}">${usuarios[id]}</option>`).join('');
        }

        applyFilters();
      }catch(e){
        console.warn('Erro loadHistorico:', e);
      }
    }

    if(btnRecarregar){
      btnRecarregar.addEventListener('click', (ev)=>{
        ev.preventDefault();
        loadHistorico();
      });
    }

    if(selTipo) selTipo.addEventListener('change', applyFilters);
    if(selUser) selUser.addEventListener('change', applyFilters);
    if(inpDe) inpDe.addEventListener('change', applyFilters);
    if(inpAte) inpAte.addEventListener('change', applyFilters);

    await loadHistorico();
  });
})();
