
// demanda-detalhe-integration.js
// Usa o backend (/api/demandas/:id e /api/demandas/:id/status)
// para preencher o detalhe da demanda e atualizar status.
(function(){
  document.addEventListener('DOMContentLoaded', async ()=>{
    if(!window.wcRequireRole) return;
    const sess = window.wcRequireRole('admin');
    if(!sess) return;
    const token = window.wcGetToken ? window.wcGetToken() : '';

    function authHeaders(extra){
      return Object.assign({}, extra||{}, {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json'
      });
    }

    function getParam(name){
      const u = new URL(location.href);
      return u.searchParams.get(name);
    }

    const id = getParam('id') || getParam('demanda') || getParam('protocolo');
    if(!id){
      alert('Nenhuma demanda informada.');
      return;
    }

    const elProto = document.getElementById('dm-protocolo');
    const elTitulo = document.getElementById('dm-titulo');
    const elCategoria = document.getElementById('dm-categoria');
    const elPrioridade = document.getElementById('dm-prioridade');
    const elStatus = document.getElementById('dm-status');
    const elDescricao = document.getElementById('dm-descricao');
    const histList = document.getElementById('dm-historico');
    const anexosBox = document.getElementById('dm-anexos');

    function setStatusBadge(el, status){
      if(!el) return;
      el.textContent = status || 'Aberta';
      const s = (status||'').toLowerCase();
      el.className = 'badge';
      if(s.includes('em andamento') || s === 'em_andamento') el.classList.add('warning');
      else if(s.includes('conclu') || s === 'concluida' || s === 'concluída') el.classList.add('success');
      else el.classList.add('info');
    }

    function renderHistorico(lista, eventos){
      if(!lista) return;
      if(!Array.isArray(eventos) || !eventos.length){
        lista.innerHTML = '<li class="hist-item"><div class="hist-msg">Nenhum evento registrado ainda.</div></li>';
        return;
      }
      lista.innerHTML = eventos.map(ev=>{
        let texto = '';
        if(typeof ev === 'string') texto = ev;
        else if(ev && ev.mensagem) texto = ev.mensagem;
        else texto = JSON.stringify(ev);
        return `<li class="hist-item"><div class="hist-msg">${texto}</div></li>`;
      }).join('');
    }

    async function loadDetalhe(){
      try{
        const r = await fetch('/api/demandas/'+id, { headers: authHeaders() });
        if(!r.ok){
          console.warn('Falha ao carregar demanda', await r.text());
          alert('Não foi possível carregar a demanda.');
          return;
        }
        const d = await r.json();

        const protocolo = d.id || id;
        document.getElementById('page-title').textContent = 'Detalhe da Demanda #'+protocolo;
        if(elProto) elProto.textContent = '#'+protocolo;
        if(elTitulo) elTitulo.textContent = d.title || '';
        if(elCategoria) elCategoria.textContent = d.category || '';
        if(elPrioridade) elPrioridade.textContent = d.priority || '—';
        if(elDescricao) elDescricao.textContent = d.description || '';
        setStatusBadge(elStatus, d.status || 'Aberta');

        if(anexosBox){
          const imgs = d.images || [];
          if(imgs.length){
            anexosBox.innerHTML = imgs.map(p=>{
              const url = p.startsWith('http') ? p : ('/'+p.replace(/^\/+/, ''));
              return `<a href="${url}" target="_blank">📎 Ver anexo</a>`;
            }).join(' ');
          }else{
            anexosBox.textContent = 'Nenhum anexo.';
          }
        }

        // carrega histórico geral filtrado para esta demanda
        try{
          const hResp = await fetch('/api/historico', { headers: authHeaders() });
          if(hResp.ok){
            const eventos = (await hResp.json()).filter(ev=> String(ev.ref_tipo||'')==='demanda' && String(ev.ref_id||'')===String(protocolo));
            renderHistorico(histList, eventos);
          }
        }catch(e){
          console.warn('Erro ao carregar histórico da demanda', e);
        }
      }catch(e){
        console.warn('Erro loadDetalhe', e);
      }
    }

    async function alterarStatus(novo){
      try{
        const r = await fetch('/api/demandas/'+id+'/status', {
          method:'POST',
          headers: authHeaders(),
          body: JSON.stringify({ status: novo })
        });
        if(!r.ok){
          alert('Falha ao atualizar status.');
          console.warn('status error', await r.text());
          return;
        }
        await loadDetalhe();
      }catch(e){
        console.warn('Erro alterarStatus', e);
      }
    }

    document.getElementById('btn-assumir')?.addEventListener('click', ()=>alterarStatus('em_andamento'));
    document.getElementById('btn-encaminhar')?.addEventListener('click', ()=>alterarStatus('em_andamento'));
    document.getElementById('btn-concluir')?.addEventListener('click', ()=>alterarStatus('concluida'));

    await loadDetalhe();
  });
})();
